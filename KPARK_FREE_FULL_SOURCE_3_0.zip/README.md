# K-PARK FREE FULL SOURCE 3.0 — 상세분석형

월 고정비 0원을 목표로 하는 개인용 K-PARK 상세분석형입니다.

구성:
- iPhone PWA
- Cloudflare Worker
- Static Assets
- D1 확장 구조
- KRX/DART Provider Adapter
- DEMO / LIVE 모드 분리
- 상세 투자분석 엔진

## K-PARK 3.0 핵심 기능

1. K-PARK 종합점수
2. 가치 / 성장 / 수익성 / 재무안정성 / 현금흐름 / 위험 점수
3. PER, PBR, ROE, EPS, BPS 해설
4. 3개 적정가치 시나리오: 보수 / 기준 / 낙관
5. 1·2·3차 기회가격과 분할매수 비중
6. 핵심 장점 / 핵심 위험 / 반대논리
7. 판단 무효화 조건
8. 초보자용 쉬운 해설
9. TOP 10
10. 데이터 연결 상태
11. 실데이터와 DEMO 데이터 명확한 표시

## 중요
실제 KRX/DART API endpoint와 인증 방식은 발급받은 서비스의 최신 공식 명세에 맞춰
worker/src/providers/krx.js 및 dart.js에 연결해야 합니다.

API 키는 GitHub나 frontend 파일에 넣지 말고 Cloudflare Secret에만 저장하십시오.

## Cloudflare 배포 명령
저장소 루트에서:

npx wrangler deploy --config worker/wrangler.toml

## 현재 모드
기본값은 demo 입니다.
키 및 실제 provider 연결 후 APP_MODE=live 로 전환할 수 있습니다.
