# K-PARK 3.0 배포

현재 GitHub → Cloudflare 자동배포 구조를 그대로 사용할 수 있습니다.

Cloudflare Build/Deploy command:
npx wrangler deploy --config worker/wrangler.toml

Root directory:
/

Production branch:
main

## API 키 발급 후
Cloudflare Worker > Settings > Variables and Secrets:
- KRX_API_KEY
- DART_API_KEY

키는 Secret으로 등록하십시오.

그 후 worker/src/providers/krx.js, dart.js의 공식 endpoint mapping을 완료하고
APP_MODE를 live로 변경합니다.
