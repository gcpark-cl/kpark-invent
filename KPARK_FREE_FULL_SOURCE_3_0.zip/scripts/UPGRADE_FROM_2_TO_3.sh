#!/usr/bin/env bash
set -e
echo "K-PARK 3.0 files are already included in this package."
echo "Copy/overwrite frontend/, worker/, docs/, README.md into your repository."
echo "Then:"
echo "  git add ."
echo '  git commit -m "Upgrade K-PARK 3.0 detailed analysis"'
echo "  git push"
